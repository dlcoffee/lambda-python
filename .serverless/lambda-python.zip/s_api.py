import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='dlcoffee',
    application_name='lambda-python',
    app_uid='k7d100HKcrXD69dP8D',
    org_uid='9a108058-bd3d-4bc1-969b-98bed531a1df',
    deployment_uid='e30b52c4-a0fb-42d5-96d8-6e8366d8a877',
    service_name='lambda-python',
    should_log_meta=True,
    should_compress_logs=True,
    disable_aws_spans=False,
    disable_http_spans=False,
    stage_name='dev',
    plugin_version='5.4.4',
    disable_frameworks_instrumentation=False,
    serverless_platform_stage='prod'
)
handler_wrapper_kwargs = {'function_name': 'lambda-python-dev-api', 'timeout': 6}
try:
    user_handler = serverless_sdk.get_user_handler('api.handler')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
